"""
run_client.py — запуск клиентской части PyRemote с GUI.
Запустите этот файл на компьютере с которого нужно управлять.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from client.gui_client import LoginWindow

if __name__ == "__main__":
    app = LoginWindow()
    app.run()
