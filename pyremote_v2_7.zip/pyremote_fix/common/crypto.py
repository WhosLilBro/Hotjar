# crypto.py

import hashlib
import ssl
import os

BASE_DIR  = os.path.dirname(__file__)
CERT_DIR  = os.path.normpath(os.path.join(BASE_DIR, "..", "certs"))
CERT_FILE = os.path.join(CERT_DIR, "server.crt")
KEY_FILE  = os.path.join(CERT_DIR, "server.key")


def hash_password(password):
    return hashlib.sha256(password.encode("utf-8")).hexdigest()


def _gen_cert():
    os.makedirs(CERT_DIR, exist_ok=True)
    if os.path.exists(CERT_FILE) and os.path.exists(KEY_FILE):
        return

    print("Generating certificate...")

    # способ 1 - через библиотеку cryptography (работает везде без openssl)
    try:
        _gen_cert_cryptography()
        print("Done (cryptography library)")
        return
    except ImportError:
        pass
    except Exception as e:
        print(f"cryptography error: {e}")

    # способ 2 - через openssl в командной строке (Linux/Mac)
    try:
        _gen_cert_openssl()
        print("Done (openssl)")
        return
    except Exception as e:
        print(f"openssl error: {e}")

    raise RuntimeError(
        "Cannot generate SSL certificate.\n"
        "Install cryptography library: pip install cryptography"
    )


def _gen_cert_cryptography():
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    import datetime

    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    name = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, u"PyRemote"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"PyRemote"),
        x509.NameAttribute(NameOID.COUNTRY_NAME, u"RU"),
    ])

    now = datetime.datetime.utcnow()
    cert = (
        x509.CertificateBuilder()
        .subject_name(name)
        .issuer_name(name)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(
            x509.BasicConstraints(ca=True, path_length=None),
            critical=True
        )
        .sign(key, hashes.SHA256())
    )

    with open(KEY_FILE, "wb") as f:
        f.write(key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption()
        ))
    with open(CERT_FILE, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))


def _gen_cert_openssl():
    import subprocess
    subprocess.run([
        "openssl", "req", "-x509", "-newkey", "rsa:2048",
        "-keyout", KEY_FILE,
        "-out",    CERT_FILE,
        "-days",   "365",
        "-nodes",
        "-subj",   "/CN=PyRemote/O=PyRemote/C=RU"
    ], check=True, capture_output=True)


def get_server_ssl_context():
    _gen_cert()
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.load_cert_chain(certfile=CERT_FILE, keyfile=KEY_FILE)
    return ctx


def get_client_ssl_context():
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx
