# protocol.py
# Описывает формат пакетов и базовые функции для работы с сокетом.
#
# Структура пакета:
#   4 байта - длина данных (big-endian)
#   1 байт  - тип пакета
#   N байт  - данные (JSON или бинарные)

import struct
import json

# типы пакетов
PKT_AUTH        = 0x01
PKT_AUTH_RESULT = 0x02
PKT_FRAME       = 0x03
PKT_MOUSE       = 0x04
PKT_KEYBOARD    = 0x05
PKT_CHAT        = 0x06
PKT_FILE_INFO   = 0x07
PKT_FILE_DATA   = 0x08
PKT_DISCONNECT  = 0x09
PKT_SCREEN_INFO = 0x0A
PKT_CANVAS_SIZE = 0x0B


def pack(pkt_type, payload):
    # собираем заголовок + данные
    header = struct.pack(">IB", len(payload), pkt_type)
    return header + payload


def pack_json(pkt_type, data):
    raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
    return pack(pkt_type, raw)


def unpack_json(payload):
    return json.loads(payload.decode("utf-8"))


def recv_packet(sock):
    # читаем ровно 5 байт заголовка
    header = _read_exact(sock, 5)
    if not header:
        raise ConnectionError("connection closed")

    data_len, pkt_type = struct.unpack(">IB", header)

    if data_len == 0:
        return pkt_type, b""

    payload = _read_exact(sock, data_len)
    if not payload:
        raise ConnectionError("connection closed while reading payload")

    return pkt_type, payload


def _read_exact(sock, n):
    # sock.recv может вернуть меньше n байт, поэтому читаем в цикле
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf
