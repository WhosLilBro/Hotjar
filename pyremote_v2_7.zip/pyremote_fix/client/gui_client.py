# gui_client.py

import tkinter as tk
from tkinter import scrolledtext, filedialog, messagebox
import threading
import os
import sys
import io
import time
from PIL import Image, ImageTk

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from client.client import PyRemoteClient

MAX_FPS       = 30
FRAME_INTERVAL = 1.0 / MAX_FPS


class LoginWindow:

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("PyRemote - Подключение")
        self.root.configure(bg="#0f2847")
        self._build_ui()
        self.root.update_idletasks()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        w = max(340, min(420, int(sw * 0.35)))
        h = max(400, min(500, int(sh * 0.60)))
        x = (sw - w) // 2
        y = (sh - h) // 2
        self.root.geometry(f"{w}x{h}+{x}+{y}")
        self.root.resizable(True, True)
        self.root.minsize(320, 380)

    def _build_ui(self):
        tk.Label(self.root, text="PyRemote", bg="#0f2847", fg="#00b4d8",
                 font=("Arial", 26, "bold")).pack(pady=(20, 4))
        tk.Label(self.root, text="Дистанционное управление ПК",
                 bg="#0f2847", fg="#aaaaaa",
                 font=("Arial", 10)).pack(pady=(0, 20))

        form = tk.Frame(self.root, bg="#0f2847")
        form.pack(padx=30, fill="x", expand=True)

        fields = [
            ("Адрес сервера:", "192.168.1.100"),
            ("Порт:",          "9000"),
            ("Логин:",         "admin"),
            ("Пароль:",        ""),
        ]
        self.inputs = {}

        for i, (lbl, default) in enumerate(fields):
            tk.Label(form, text=lbl, bg="#0f2847", fg="#aaaaaa",
                     font=("Arial", 10), anchor="w").grid(
                row=i, column=0, sticky="w", pady=5)
            show = "*" if lbl == "Пароль:" else ""
            e = tk.Entry(form, font=("Arial", 11), show=show,
                         bg="#1a2b3c", fg="white",
                         insertbackground="white", relief="flat", bd=6)
            e.insert(0, default)
            e.grid(row=i, column=1, sticky="ew", padx=(10, 0), pady=5)
            self.inputs[lbl] = e

        form.columnconfigure(1, weight=1)

        self.var_msg = tk.StringVar()
        tk.Label(self.root, textvariable=self.var_msg,
                 bg="#0f2847", fg="#e63946", font=("Arial", 9),
                 wraplength=360, justify="center").pack(pady=6, padx=10)

        self.btn = tk.Button(self.root, text="Подключиться",
                             command=self._connect,
                             bg="#00b4d8", fg="white",
                             font=("Arial", 12, "bold"),
                             relief="flat", padx=20, pady=8, cursor="hand2")
        self.btn.pack(pady=10)
        self.root.bind("<Return>", lambda e: self._connect())

    def _connect(self):
        host     = self.inputs["Адрес сервера:"].get().strip()
        port_str = self.inputs["Порт:"].get().strip()
        login    = self.inputs["Логин:"].get().strip()
        password = self.inputs["Пароль:"].get()

        if not host or not login or not password:
            self.var_msg.set("Заполните все поля")
            return
        try:
            port = int(port_str)
        except ValueError:
            self.var_msg.set("Неверный порт")
            return

        self.btn.configure(state="disabled", text="Подключение...")
        self.var_msg.set("")
        threading.Thread(target=self._do_connect,
                         args=(host, port, login, password), daemon=True).start()

    def _do_connect(self, host, port, login, password):
        c = PyRemoteClient(host, port, login, password)
        ok, msg = c.connect()

        def finish():
            if ok:
                self.root.destroy()
                MainWindow(c, login).run()
            else:
                self.var_msg.set(msg)
                self.btn.configure(state="normal", text="Подключиться")

        self.root.after(0, finish)

    def run(self):
        self.root.mainloop()


class MainWindow:

    def __init__(self, client, login):
        self.client = client
        self.login  = login

        self.root = tk.Tk()
        self.root.title(f"PyRemote - {login} @ {client.host}")
        self.root.configure(bg="#1a2b3c")

        self._server_w     = 1920
        self._server_h     = 1080
        self._last_img     = None
        self._disconnected = False

        self._last_move_t  = 0
        self._move_delay   = 1.0 / 60
        self._last_draw_t  = 0

        self._fps_count = 0
        self._fps_ts    = time.time()

        self._ctrl_held  = False
        self._shift_held = False
        self._alt_held   = False
        self._win_held   = False

        self._build_ui()
        self._bind_input()
        self._setup_callbacks()

        self.root.protocol("WM_DELETE_WINDOW", self._close)

        self.root.update_idletasks()
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        w = min(1200, int(sw * 0.92))
        h = min(750,  int(sh * 0.88))
        x = (sw - w) // 2
        y = (sh - h) // 2
        self.root.geometry(f"{w}x{h}+{x}+{y}")

        self.root.after(600, self._send_canvas_size)
        self.root.after(200, self.canvas.focus_set)

    def _build_ui(self):
        top = tk.Frame(self.root, bg="#0f2847", pady=6, padx=12)
        top.pack(fill="x")
        tk.Label(top, text="PyRemote", bg="#0f2847", fg="#00b4d8",
                 font=("Arial", 13, "bold")).pack(side="left")
        tk.Label(top,
                 text=f"{self.login} @ {self.client.host}:{self.client.port}",
                 bg="#0f2847", fg="#aaaaaa",
                 font=("Arial", 10)).pack(side="left", padx=12)
        tk.Button(top, text="Отключиться", command=self._close,
                  bg="#e63946", fg="white", font=("Arial", 9, "bold"),
                  relief="flat", padx=8, pady=2, cursor="hand2").pack(side="right")

        body = tk.Frame(self.root, bg="#1a2b3c")
        body.pack(fill="both", expand=True, padx=6, pady=6)

        left = tk.Frame(body, bg="#000")
        left.pack(side="left", fill="both", expand=True)

        self.canvas = tk.Canvas(left, bg="#111", cursor="none",
                                highlightthickness=0)
        self.canvas.pack(fill="both", expand=True)
        self.canvas.create_text(450, 280,
                                text="Ожидание видеопотока...",
                                fill="#aaaaaa", font=("Arial", 14), tags="msg")
        self._cursor = self.canvas.create_oval(-20, -20, -6, -6,
                                               outline="#00b4d8", width=2,
                                               tags="cursor")

        right = tk.Frame(body, bg="#1a2b3c", width=220)
        right.pack(side="right", fill="y", padx=(6, 0))
        right.pack_propagate(False)

        chat_f = tk.LabelFrame(right, text="Чат", bg="#1a2b3c",
                               fg="#aaaaaa", font=("Arial", 10), padx=5, pady=5)
        chat_f.pack(fill="both", expand=True)

        self.chat_box = scrolledtext.ScrolledText(
            chat_f, height=12, state="disabled",
            bg="#0f2847", fg="#e0e0e0",
            font=("Arial", 9), relief="flat", wrap="word")
        self.chat_box.pack(fill="both", expand=True, pady=(0, 5))

        row = tk.Frame(chat_f, bg="#1a2b3c")
        row.pack(fill="x")
        self.chat_in = tk.Entry(row, font=("Arial", 10), bg="#0f2847",
                                fg="white", insertbackground="white",
                                relief="flat", bd=4)
        self.chat_in.pack(side="left", fill="x", expand=True)
        self.chat_in.bind("<Return>", lambda e: self._send_chat())
        tk.Button(row, text="->", command=self._send_chat,
                  bg="#00b4d8", fg="white", font=("Arial", 10, "bold"),
                  relief="flat", padx=5, cursor="hand2").pack(side="right",
                                                              padx=(3, 0))

        files_f = tk.LabelFrame(right, text="Файлы", bg="#1a2b3c",
                                fg="#aaaaaa", font=("Arial", 10), padx=5, pady=5)
        files_f.pack(fill="x", pady=(6, 0))
        tk.Button(files_f, text="Отправить файл...", command=self._send_file,
                  bg="#0f2847", fg="#00b4d8", font=("Arial", 9),
                  relief="flat", padx=6, pady=4, cursor="hand2",
                  anchor="w").pack(fill="x")
        self.lbl_file = tk.Label(files_f, text="", bg="#1a2b3c",
                                 fg="#aaaaaa", font=("Arial", 8), wraplength=200)
        self.lbl_file.pack(fill="x", pady=(3, 0))

        bar = tk.Frame(self.root, bg="#0f2847", pady=3, padx=12)
        bar.pack(fill="x")
        self.lbl_conn = tk.Label(bar, text="● Подключено", bg="#0f2847",
                                 fg="#06a77d", font=("Arial", 9))
        self.lbl_conn.pack(side="left")
        self.lbl_fps = tk.Label(bar, text="", bg="#0f2847",
                                fg="#aaaaaa", font=("Arial", 9))
        self.lbl_fps.pack(side="right")
        self.lbl_res = tk.Label(bar, text="", bg="#0f2847",
                                fg="#aaaaaa", font=("Arial", 9))
        self.lbl_res.pack(side="right", padx=10)

    def _send_canvas_size(self):
        from common.protocol import pack_json, PKT_CANVAS_SIZE
        if not self.client.connected:
            return
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw > 1 and ch > 1:
            self.client._send(pack_json(PKT_CANVAS_SIZE, {"w": cw, "h": ch}))
        self.root.after(2000, self._send_canvas_size)

    def _bind_input(self):
        c = self.canvas
        c.bind("<Motion>",          self._mouse_move)
        c.bind("<Button-1>",        self._mouse_click)
        c.bind("<Double-Button-1>", self._mouse_dblclick)
        c.bind("<Button-3>",        self._mouse_rclick)
        c.bind("<MouseWheel>",      self._mouse_scroll)
        c.bind("<Button-4>",        self._scroll_up)
        c.bind("<Button-5>",        self._scroll_down)
        c.bind("<Enter>",           lambda e: c.focus_set())
        self.root.bind("<KeyPress>",   self._key_down)
        self.root.bind("<KeyRelease>", self._key_up)
        self.root.bind("<Button-1>",   self._refocus)

    def _refocus(self, event):
        if event.widget != self.chat_in:
            self.canvas.focus_set()

    def _setup_callbacks(self):
        self.client.on_frame                = self._on_frame
        self.client.on_chat                 = self._on_chat
        self.client.on_disconnect           = self._on_disconnect
        self.client.on_disconnect_immediate = self._set_disconnected
        self.client.on_screen_info          = self._on_screen_info

    def _set_disconnected(self):
        self._disconnected = True

    def _on_screen_info(self, w, h):
        self._server_w = w
        self._server_h = h
        self.root.after(0, lambda: self.lbl_res.configure(text=f"{w}x{h}"))

    def _on_frame(self, jpeg):
        if self._disconnected:
            return
        now = time.time()
        if now - self._last_draw_t < FRAME_INTERVAL:
            return
        self._last_draw_t = now
        try:
            img = Image.open(io.BytesIO(jpeg))
            img.load()
            self.root.after(0, lambda i=img: self._draw_frame(i))
            self._fps_count += 1
        except Exception:
            pass

    def _draw_frame(self, img):
        if self._disconnected:
            return
        self.canvas.delete("msg")
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw > 1 and ch > 1 and (img.width != cw or img.height != ch):
            img = img.resize((cw, ch), Image.BILINEAR)
        photo = ImageTk.PhotoImage(img)
        self._last_img = photo
        self.canvas.delete("frame")
        self.canvas.create_image(0, 0, anchor="nw", image=photo, tags="frame")
        self.canvas.tag_raise("cursor")

        now = time.time()
        if now - self._fps_ts >= 1.0:
            self.lbl_fps.configure(text=f"FPS: {self._fps_count}")
            self._fps_count = 0
            self._fps_ts = now

    def _scale(self, event):
        cw = self.canvas.winfo_width()
        ch = self.canvas.winfo_height()
        if cw <= 1 or ch <= 1:
            return event.x, event.y
        x = int(event.x * self._server_w / cw)
        y = int(event.y * self._server_h / ch)
        return x, y

    def _mouse_move(self, event):
        if self._disconnected:
            return
        now = time.time()
        if now - self._last_move_t < self._move_delay:
            return
        self._last_move_t = now
        self.canvas.coords(self._cursor,
                           event.x - 7, event.y - 7,
                           event.x + 7, event.y + 7)
        self.canvas.tag_raise("cursor")
        x, y = self._scale(event)
        self.client.send_mouse_move(x, y)

    def _mouse_click(self, event):
        if self._disconnected:
            return
        self.canvas.focus_set()
        x, y = self._scale(event)
        self.client.send_mouse_click(x, y)

    def _mouse_dblclick(self, event):
        if self._disconnected:
            return
        x, y = self._scale(event)
        self.client.send_mouse_double_click(x, y)

    def _mouse_rclick(self, event):
        if self._disconnected:
            return
        x, y = self._scale(event)
        self.client.send_mouse_right_click(x, y)

    def _mouse_scroll(self, event):
        if self._disconnected:
            return
        x, y = self._scale(event)
        dy = 3 if event.delta > 0 else -3
        self.client.send_mouse_scroll(x, y, dy)

    def _scroll_up(self, event):
        if self._disconnected:
            return
        x, y = self._scale(event)
        self.client.send_mouse_scroll(x, y, 3)

    def _scroll_down(self, event):
        if self._disconnected:
            return
        x, y = self._scale(event)
        self.client.send_mouse_scroll(x, y, -3)

    SINGLE_KEYS = {
        "Return":    "enter",
        "BackSpace": "backspace",
        "Delete":    "delete",
        "Escape":    "esc",
        "Tab":       "tab",
        "space":     "space",
        "Up":        "up",
        "Down":      "down",
        "Left":      "left",
        "Right":     "right",
        "Home":      "home",
        "End":       "end",
        "Prior":     "pageup",
        "Next":      "pagedown",
        "Insert":    "insert",
        "Print":     "printscreen",
        "Pause":     "pause",
        "F1":  "f1",  "F2":  "f2",  "F3":  "f3",  "F4":  "f4",
        "F5":  "f5",  "F6":  "f6",  "F7":  "f7",  "F8":  "f8",
        "F9":  "f9",  "F10": "f10", "F11": "f11", "F12": "f12",
        "KP_Enter":  "enter",
        "KP_Delete": "delete",
        "KP_End":    "end",
        "KP_Down":   "down",
        "KP_Next":   "pagedown",
        "KP_Left":   "left",
        "KP_Right":  "right",
        "KP_Home":   "home",
        "KP_Up":     "up",
        "KP_Prior":  "pageup",
        "KP_Insert": "insert",
    }

    MODIFIERS = {
        "Control_L", "Control_R",
        "Alt_L", "Alt_R",
        "Shift_L", "Shift_R",
        "Super_L", "Super_R",
        "Caps_Lock", "Num_Lock", "Scroll_Lock",
        "ISO_Level3_Shift",
    }

    def _key_down(self, event):
        if self._disconnected:
            return
        if self.root.focus_get() == self.chat_in:
            return

        sym = event.keysym

        if sym in ("Control_L", "Control_R"):
            self._ctrl_held = True
            return
        if sym in ("Shift_L", "Shift_R"):
            self._shift_held = True
            return
        if sym in ("Alt_L", "Alt_R"):
            self._alt_held = True
            return
        if sym in ("Super_L", "Super_R"):
            self._win_held = True
            return
        if sym in self.MODIFIERS:
            return

        mods = []
        if self._ctrl_held:
            mods.append("ctrl")
        if self._shift_held:
            mods.append("shift")
        if self._alt_held:
            mods.append("alt")
        if self._win_held:
            mods.append("win")

        # дополнительная проверка через event.state
        # на случай если пропустили KeyPress модификатора
        if not self._ctrl_held and (event.state & 0x4):
            if "ctrl" not in mods:
                mods.append("ctrl")
        if not self._shift_held and (event.state & 0x1):
            if "shift" not in mods:
                mods.append("shift")

        if sym in self.SINGLE_KEYS:
            key = self.SINGLE_KEYS[sym]
        elif len(sym) == 1:
            key = sym.lower()
        else:
            key = sym.lower()

        if mods:
            self.client.send_hotkey(*mods, key)
        elif sym in self.SINGLE_KEYS:
            self.client.send_key_press(self.SINGLE_KEYS[sym])
        else:
            char = event.char
            if char and char.isprintable():
                self.client.send_text(char)
            elif key:
                self.client.send_key_press(key)

    def _key_up(self, event):
        sym = event.keysym
        if sym in ("Control_L", "Control_R"):
            self._ctrl_held = False
        elif sym in ("Shift_L", "Shift_R"):
            self._shift_held = False
        elif sym in ("Alt_L", "Alt_R"):
            self._alt_held = False
        elif sym in ("Super_L", "Super_R"):
            self._win_held = False

    def _send_chat(self):
        if self._disconnected:
            return
        text = self.chat_in.get().strip()
        if not text:
            return
        self.chat_in.delete(0, "end")
        self.client.send_chat(text)
        self._append_chat(f"Вы: {text}")
        self.root.after(80, self.canvas.focus_set)

    def _on_chat(self, text, sender):
        name = sender if sender else "Сервер"
        self.root.after(0, lambda: self._append_chat(f"{name}: {text}"))

    def _append_chat(self, line):
        from datetime import datetime
        ts = datetime.now().strftime("%H:%M")
        self.chat_box.configure(state="normal")
        self.chat_box.insert("end", f"[{ts}] {line}\n")
        self.chat_box.see("end")
        self.chat_box.configure(state="disabled")

    def _send_file(self):
        if self._disconnected:
            return
        path = filedialog.askopenfilename(title="Выберите файл", parent=self.root)
        if not path:
            return
        name = os.path.basename(path)
        size = os.path.getsize(path)
        self.lbl_file.configure(
            text=f"Отправка: {name} ({size // 1024} КБ)...", fg="#00b4d8")

        def do():
            self.client.send_file(path)
            self.root.after(0, lambda: self.lbl_file.configure(
                text=f"Готово: {name}", fg="#06a77d"))

        threading.Thread(target=do, daemon=True).start()

    def _on_disconnect(self, reason):
        self.root.after(0, lambda: self._show_disconnect(reason))

    def _show_disconnect(self, reason):
        self.lbl_conn.configure(text="● Отключено", fg="#e63946")
        self.lbl_fps.configure(text="")
        self.canvas.delete("frame")
        self.canvas.delete("cursor")
        cw = max(self.canvas.winfo_width(), 200)
        ch = max(self.canvas.winfo_height(), 200)
        self.canvas.create_text(cw // 2, ch // 2,
                                text="Соединение разорвано",
                                fill="#e63946", font=("Arial", 16, "bold"))
        self.canvas.create_text(cw // 2, ch // 2 + 30,
                                text=reason,
                                fill="#aaaaaa", font=("Arial", 11))
        messagebox.showwarning("Отключено",
                               f"Соединение с сервером прервано.\n\n{reason}",
                               parent=self.root)

    def _close(self):
        self.client.disconnect()
        self.root.destroy()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    LoginWindow().run()
