# client.py

import socket
import threading
import time
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from common.protocol import (
    recv_packet, pack_json, pack, unpack_json,
    PKT_AUTH, PKT_AUTH_RESULT, PKT_FRAME,
    PKT_MOUSE, PKT_KEYBOARD, PKT_CHAT,
    PKT_FILE_INFO, PKT_FILE_DATA,
    PKT_DISCONNECT, PKT_SCREEN_INFO
)
from common.crypto import hash_password, get_client_ssl_context

# ограничение FPS на уровне получения кадров
MAX_FPS        = 30
FRAME_INTERVAL = 1.0 / MAX_FPS


class PyRemoteClient:

    def __init__(self, host, port, login, password):
        self.host     = host
        self.port     = port
        self.login    = login
        self.password = password

        self.conn      = None
        self.connected = False

        self._send_lock  = threading.Lock()
        self._frame_lock = threading.Lock()
        self._last_frame = None
        self._last_frame_t = 0  # время последнего принятого кадра

        self.on_frame                = None
        self.on_chat                 = None
        self.on_disconnect           = None
        self.on_disconnect_immediate = None
        self.on_screen_info          = None

    def connect(self):
        ssl_ctx = get_client_ssl_context()
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            sock.connect((self.host, self.port))
            self.conn = ssl_ctx.wrap_socket(sock, server_hostname=self.host)
            self.conn.settimeout(None)
        except (socket.timeout, ConnectionRefusedError, OSError) as e:
            return False, f"Не удалось подключиться: {e}"

        ok, msg = self._do_auth()
        if not ok:
            self.conn.close()
            return False, msg

        self.connected = True
        threading.Thread(target=self._recv_loop, daemon=True).start()
        threading.Thread(target=self._frame_loop, daemon=True).start()
        return True, "OK"

    def _do_auth(self):
        pwd_hash = hash_password(self.password)
        self.conn.sendall(pack_json(PKT_AUTH, {
            "login": self.login,
            "password_hash": pwd_hash
        }))
        pkt_type, payload = recv_packet(self.conn)
        if pkt_type != PKT_AUTH_RESULT:
            return False, f"Неожиданный ответ: {pkt_type}"
        data = unpack_json(payload)
        return data.get("success", False), data.get("message", "")

    def _recv_loop(self):
        reason = "Соединение закрыто"
        try:
            while self.connected:
                pkt_type, payload = recv_packet(self.conn)

                if pkt_type == PKT_FRAME:
                    # throttle на уровне приёма - отбрасываем лишние кадры
                    now = time.time()
                    if now - self._last_frame_t >= FRAME_INTERVAL:
                        with self._frame_lock:
                            self._last_frame = payload
                        self._last_frame_t = now

                elif pkt_type == PKT_SCREEN_INFO:
                    d = unpack_json(payload)
                    if self.on_screen_info:
                        self.on_screen_info(d.get("screen_w", 1920),
                                            d.get("screen_h", 1080))

                elif pkt_type == PKT_CHAT:
                    d = unpack_json(payload)
                    if self.on_chat:
                        self.on_chat(d.get("text", ""), d.get("sender", ""))

                elif pkt_type == PKT_DISCONNECT:
                    reason = "Сервер завершил сессию"
                    break

        except (ConnectionError, OSError) as e:
            reason = str(e)
        finally:
            self.connected = False
            if self.on_disconnect_immediate:
                try:
                    self.on_disconnect_immediate()
                except Exception:
                    pass
            try:
                self.conn.close()
            except Exception:
                pass
            if self.on_disconnect:
                self.on_disconnect(reason)

    def _frame_loop(self):
        # отдельный поток для передачи кадров в GUI
        # не накапливаем очередь - всегда берём только последний кадр
        while self.connected:
            frame = None
            with self._frame_lock:
                if self._last_frame is not None:
                    frame = self._last_frame
                    self._last_frame = None

            if frame is not None:
                if self.on_frame:
                    self.on_frame(frame)
                time.sleep(0.001)
            else:
                time.sleep(0.005)

    def send_mouse_move(self, x, y):
        self._send(pack_json(PKT_MOUSE, {"event": "move", "x": x, "y": y}))

    def send_mouse_click(self, x, y):
        self._send(pack_json(PKT_MOUSE, {"event": "click", "x": x, "y": y}))

    def send_mouse_double_click(self, x, y):
        self._send(pack_json(PKT_MOUSE, {"event": "double_click", "x": x, "y": y}))

    def send_mouse_right_click(self, x, y):
        self._send(pack_json(PKT_MOUSE, {"event": "right_click", "x": x, "y": y}))

    def send_mouse_scroll(self, x, y, dy):
        self._send(pack_json(PKT_MOUSE, {"event": "scroll", "x": x, "y": y, "dy": dy}))

    def send_key_press(self, key):
        self._send(pack_json(PKT_KEYBOARD, {"event": "press", "key": key}))

    def send_hotkey(self, *keys):
        self._send(pack_json(PKT_KEYBOARD, {"event": "hotkey", "keys": list(keys)}))

    def send_text(self, text):
        self._send(pack_json(PKT_KEYBOARD, {"event": "write", "text": text}))

    def send_chat(self, text):
        self._send(pack_json(PKT_CHAT, {"text": text, "sender": self.login}))

    def send_file(self, filepath):
        if not os.path.isfile(filepath):
            return
        filename = os.path.basename(filepath)
        filesize = os.path.getsize(filepath)
        self._send(pack_json(PKT_FILE_INFO, {
            "filename": filename,
            "filesize": filesize
        }))
        with open(filepath, "rb") as f:
            while True:
                block = f.read(65536)
                if not block:
                    break
                self._send(pack(PKT_FILE_DATA, block))

    def disconnect(self):
        if self.connected:
            try:
                self._send(pack_json(PKT_DISCONNECT, {}))
            except Exception:
                pass
            self.connected = False
            try:
                self.conn.close()
            except Exception:
                pass

    def _send(self, data):
        if self.connected and self.conn:
            try:
                with self._send_lock:
                    self.conn.sendall(data)
            except (ConnectionError, OSError):
                self.connected = False
