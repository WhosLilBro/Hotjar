"""
run_server.py — запуск серверной части PyRemote с GUI.
Запустите этот файл на компьютере которым нужно управлять.
"""
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from server.gui_server import ServerGUI

if __name__ == "__main__":
    app = ServerGUI()
    app.run()
