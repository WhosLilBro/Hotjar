# gui_server.py

import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

LOG_DIR  = os.path.join(os.path.dirname(__file__), "..", "logs")
LOG_FILE = os.path.join(LOG_DIR, "sessions.log")


def write_log(msg):
    os.makedirs(LOG_DIR, exist_ok=True)
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] {msg}\n")
    except Exception:
        pass


def _get_all_ips():
    # получаем все IPv4 адреса через все доступные методы
    import socket
    ips = set()

    # метод 1 - через hostname
    try:
        hostname = socket.gethostname()
        for info in socket.getaddrinfo(hostname, None):
            ip = info[4][0]
            if ':' not in ip:
                ips.add(ip)
    except Exception:
        pass

    # метод 2 - UDP трюк (показывает IP через который идёт трафик на 8.8.8.8)
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ips.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass

    # метод 3 - через netifaces если установлен
    try:
        import netifaces
        for iface in netifaces.interfaces():
            addrs = netifaces.ifaddresses(iface)
            if netifaces.AF_INET in addrs:
                for a in addrs[netifaces.AF_INET]:
                    ips.add(a['addr'])
    except ImportError:
        pass

    # метод 4 - Linux: через 'ip addr show'
    try:
        import subprocess
        result = subprocess.run(
            ["ip", "-4", "addr", "show"],
            capture_output=True, text=True, timeout=2
        )
        import re
        for match in re.finditer(r'inet\s+(\d+\.\d+\.\d+\.\d+)', result.stdout):
            ips.add(match.group(1))
    except Exception:
        pass

    # метод 5 - Linux: читаем /proc/net/fib_trie
    try:
        with open('/proc/net/fib_trie') as f:
            content = f.read()
        import re
        # ищем LOCAL блоки
        for match in re.finditer(r'(\d+\.\d+\.\d+\.\d+).*?LOCAL', content, re.DOTALL):
            ip = match.group(1)
            if ip.count('.') == 3:
                ips.add(ip)
    except Exception:
        pass

    return list(ips)


def _get_local_ip():
    import socket
    candidates = _get_all_ips()

    # приоритет 1: 192.168.x.x кроме 192.168.56.x (VirtualBox Host-Only)
    for ip in sorted(candidates):
        if ip.startswith("192.168.") and not ip.startswith("192.168.56."):
            return ip

    # приоритет 2: 192.168.56.x
    for ip in candidates:
        if ip.startswith("192.168."):
            return ip

    # приоритет 3: 172.16-31.x.x
    for ip in candidates:
        if ip.startswith("172."):
            parts = ip.split(".")
            try:
                if 16 <= int(parts[1]) <= 31:
                    return ip
            except Exception:
                pass

    # всё остальное кроме loopback, NAT и VPN
    bad = ("127.", "10.", "26.", "169.254.")
    for ip in candidates:
        if not any(ip.startswith(b) for b in bad):
            return ip

    for ip in candidates:
        if not ip.startswith("127."):
            return ip

    return "127.0.0.1"


def open_mss():
    # поддержка разных версий mss
    import mss as mss_module
    if hasattr(mss_module, 'MSS'):
        return mss_module.MSS()
    return mss_module.mss()


def grab_screen(sct, monitor):
    from PIL import Image
    shot = sct.grab(monitor)
    try:
        img = Image.frombytes("RGB", shot.size, shot.rgb)
    except Exception:
        try:
            img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
        except Exception:
            img = Image.frombytes("RGBA", shot.size, shot.bgra).convert("RGB")
    return img


class ServerGUI:

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("PyRemote - Сервер")
        self.root.geometry("600x500")
        self.root.resizable(False, False)
        self.root.configure(bg="#1a2b3c")
        self._running   = False
        self._srv_sock  = None
        self._sessions  = []  # список активных событий active для принудительного закрытия
        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)

    def _build_ui(self):
        hdr = tk.Frame(self.root, bg="#0f2847", pady=12)
        hdr.pack(fill="x")
        tk.Label(hdr, text="PyRemote", bg="#0f2847", fg="#00b4d8",
                 font=("Arial", 20, "bold")).pack()
        tk.Label(hdr, text="Серверная часть", bg="#0f2847", fg="#aaaaaa",
                 font=("Arial", 10)).pack()

        sf = tk.Frame(self.root, bg="#1a2b3c", pady=10)
        sf.pack(fill="x", padx=20)
        tk.Label(sf, text="Статус:", bg="#1a2b3c", fg="#aaaaaa",
                 font=("Arial", 11)).pack(side="left")
        self.lbl_status = tk.Label(sf, text="Остановлен", bg="#1a2b3c",
                                   fg="#e63946", font=("Arial", 11, "bold"))
        self.lbl_status.pack(side="left", padx=8)
        self.lbl_addr = tk.Label(sf, text="", bg="#1a2b3c", fg="#aaaaaa",
                                 font=("Arial", 10))
        self.lbl_addr.pack(side="right")

        cfg = tk.Frame(self.root, bg="#1a2b3c", pady=5)
        cfg.pack(fill="x", padx=20)
        tk.Label(cfg, text="Порт:", bg="#1a2b3c", fg="#aaaaaa",
                 font=("Arial", 10)).grid(row=0, column=0, sticky="w")
        self.var_port = tk.StringVar(value="9000")
        tk.Entry(cfg, textvariable=self.var_port, width=8,
                 font=("Arial", 10)).grid(row=0, column=1, padx=(5, 20), sticky="w")
        tk.Label(cfg, text="FPS:", bg="#1a2b3c", fg="#aaaaaa",
                 font=("Arial", 10)).grid(row=0, column=2, sticky="w")
        self.var_fps = tk.StringVar(value="30")
        tk.Entry(cfg, textvariable=self.var_fps, width=5,
                 font=("Arial", 10)).grid(row=0, column=3, padx=(5, 20), sticky="w")
        tk.Label(cfg, text="Качество:", bg="#1a2b3c", fg="#aaaaaa",
                 font=("Arial", 10)).grid(row=0, column=4, sticky="w")
        self.var_quality = tk.StringVar(value="85")
        tk.Entry(cfg, textvariable=self.var_quality, width=5,
                 font=("Arial", 10)).grid(row=0, column=5, padx=5, sticky="w")

        bf = tk.Frame(self.root, bg="#1a2b3c", pady=10)
        bf.pack(fill="x", padx=20)
        self.btn_start = tk.Button(bf, text="Запустить", command=self._start,
                                   bg="#06a77d", fg="white",
                                   font=("Arial", 11, "bold"),
                                   relief="flat", padx=16, pady=6, cursor="hand2")
        self.btn_start.pack(side="left")
        self.btn_stop = tk.Button(bf, text="Остановить", command=self._stop,
                                  bg="#e63946", fg="white",
                                  font=("Arial", 11, "bold"),
                                  relief="flat", padx=16, pady=6,
                                  cursor="hand2", state="disabled")
        self.btn_stop.pack(side="left", padx=10)

        cf = tk.LabelFrame(self.root, text="Подключения", bg="#1a2b3c",
                           fg="#aaaaaa", font=("Arial", 10), pady=5, padx=10)
        cf.pack(fill="x", padx=20, pady=5)
        cols = ("IP", "Пользователь", "Подключён")
        self.tbl = ttk.Treeview(cf, columns=cols, show="headings", height=3)
        for c in cols:
            self.tbl.heading(c, text=c)
            self.tbl.column(c, width=180)
        self.tbl.pack(fill="x")

        lf = tk.LabelFrame(self.root, text="Журнал", bg="#1a2b3c",
                           fg="#aaaaaa", font=("Arial", 10), pady=5, padx=10)
        lf.pack(fill="both", expand=True, padx=20, pady=(5, 15))
        self.log_box = scrolledtext.ScrolledText(lf, height=8, state="disabled",
                                                 bg="#0f2847", fg="#e0e0e0",
                                                 font=("Courier New", 9),
                                                 relief="flat")
        self.log_box.pack(fill="both", expand=True)

    def log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {msg}\n"
        def _do():
            self.log_box.configure(state="normal")
            self.log_box.insert("end", line)
            self.log_box.see("end")
            self.log_box.configure(state="disabled")
        self.root.after(0, _do)

    def add_conn(self, ip, user):
        def _do():
            ts = datetime.now().strftime("%H:%M:%S")
            try:
                self.tbl.insert("", "end", iid=ip, values=(ip, user, ts))
            except Exception:
                pass
        self.root.after(0, _do)

    def del_conn(self, ip):
        def _do():
            try:
                self.tbl.delete(ip)
            except Exception:
                pass
        self.root.after(0, _do)

    def _start(self):
        try:
            port    = int(self.var_port.get())
            fps     = int(self.var_fps.get())
            quality = int(self.var_quality.get())
        except ValueError:
            self.log("Ошибка: проверьте значения порта, FPS и качества")
            return

        self._running = True
        self.btn_start.configure(state="disabled")
        self.btn_stop.configure(state="normal")
        self.lbl_status.configure(text="Работает", fg="#06a77d")

        import socket
        local_ip = _get_local_ip()

        self.lbl_addr.configure(text=f"{local_ip}:{port}")
        self.log(f"Запущен на {local_ip}:{port}, fps={fps}, quality={quality}")
        write_log(f"SERVER STARTED: {local_ip}:{port}")

        threading.Thread(target=self._server_thread,
                         args=(port, fps, quality), daemon=True).start()

    def _server_thread(self, port, fps, quality):
        import socket as S
        import ssl
        from server.auth import ensure_default_user
        from common.crypto import get_server_ssl_context

        ensure_default_user()

        try:
            ctx = get_server_ssl_context()
        except Exception as e:
            self.log(f"Ошибка SSL: {e}")
            self.root.after(0, self._reset_ui)
            return

        srv = S.socket(S.AF_INET, S.SOCK_STREAM)
        srv.setsockopt(S.SOL_SOCKET, S.SO_REUSEADDR, 1)
        srv.bind(("0.0.0.0", port))
        srv.listen(5)
        srv.settimeout(1.0)
        self._srv_sock = srv
        self.log("Ожидание подключений...")

        while self._running:
            try:
                conn, addr = srv.accept()
            except S.timeout:
                continue
            except Exception:
                break
            try:
                tls = ctx.wrap_socket(conn, server_side=True)
            except ssl.SSLError as e:
                self.log(f"SSL ошибка: {e}")
                conn.close()
                continue
            threading.Thread(target=self._handle,
                             args=(tls, addr, fps, quality), daemon=True).start()

        srv.close()
        write_log("SERVER STOPPED")

    def _handle(self, conn, addr, fps, quality):
        import mss
        import io
        import time
        import pyautogui
        from common.protocol import (
            recv_packet, pack_json, pack, unpack_json,
            PKT_AUTH, PKT_AUTH_RESULT, PKT_DISCONNECT,
            PKT_MOUSE, PKT_KEYBOARD, PKT_CHAT,
            PKT_FILE_INFO, PKT_FILE_DATA, PKT_FRAME,
            PKT_SCREEN_INFO, PKT_CANVAS_SIZE
        )
        from server.auth import verify_user

        pyautogui.FAILSAFE = False
        ip    = addr[0]
        login = ""

        lock = threading.Lock()
        def send(data):
            with lock:
                try:
                    conn.sendall(data)
                except Exception:
                    pass

        canvas_w = [0]
        canvas_h = [0]

        # авторизация
        try:
            pkt_type, payload = recv_packet(conn)
            d        = unpack_json(payload)
            login    = d.get("login", "")
            pwd_hash = d.get("password_hash", "")

            if not verify_user(login, pwd_hash):
                send(pack_json(PKT_AUTH_RESULT, {
                    "success": False, "message": "Неверный логин или пароль"
                }))
                conn.close()
                self.log(f"Отказ в доступе: {ip}")
                write_log(f"AUTH FAILED: login={login} ip={ip}")
                return

            send(pack_json(PKT_AUTH_RESULT, {
                "success": True, "message": "OK"
            }))

            # получаем разрешение экрана
            with open_mss() as sct:
                mon = sct.monitors[1] if len(sct.monitors) > 1 else sct.monitors[0]
                sw  = mon["width"]
                sh  = mon["height"]
            canvas_w[0] = sw
            canvas_h[0] = sh
            send(pack_json(PKT_SCREEN_INFO, {"screen_w": sw, "screen_h": sh}))

        except Exception as e:
            self.log(f"Ошибка авторизации от {ip}: {e}")
            conn.close()
            return

        self.log(f"Подключён: {login} @ {ip}")
        self.add_conn(ip, login)
        write_log(f"CONNECTED: user={login} ip={ip}")

        active   = threading.Event()
        active.set()
        self._sessions.append(active)  # регистрируем для принудительного закрытия
        interval = 1.0 / fps

        def stream():
            try:
                with open_mss() as sct:
                    monitors = sct.monitors
                    # берём первый реальный монитор
                    monitor = monitors[1] if len(monitors) > 1 else monitors[0]
                    self.log(f"Трансляция экрана: {monitor['width']}x{monitor['height']}")

                    while active.is_set():
                        t0 = time.time()
                        try:
                            img = grab_screen(sct, monitor)

                            cw = canvas_w[0]
                            ch = canvas_h[0]
                            if cw > 0 and ch > 0:
                                from PIL import Image
                                img = img.resize((cw, ch), Image.BILINEAR)

                            buf = io.BytesIO()
                            img.save(buf, format="JPEG", quality=quality)
                            data = buf.getvalue()
                            send(pack(PKT_FRAME, data))

                        except Exception as e:
                            self.log(f"Ошибка захвата: {e}")
                            active.clear()
                            break

                        elapsed = time.time() - t0
                        left = interval - elapsed
                        if left > 0:
                            time.sleep(left)
            except Exception as e:
                self.log(f"Поток трансляции упал: {e}")
                active.clear()

        threading.Thread(target=stream, daemon=True).start()

        try:
            while active.is_set():
                pkt_type, payload = recv_packet(conn)

                if pkt_type == PKT_DISCONNECT:
                    break

                elif pkt_type == PKT_CANVAS_SIZE:
                    d = unpack_json(payload)
                    canvas_w[0] = d.get("w", canvas_w[0])
                    canvas_h[0] = d.get("h", canvas_h[0])

                elif pkt_type == PKT_MOUSE:
                    d  = unpack_json(payload)
                    ev = d.get("event")
                    x  = int(d.get("x", 0))
                    y  = int(d.get("y", 0))
                    try:
                        if ev == "move":
                            cx, cy = pyautogui.position()
                            if abs(cx - x) > 3 or abs(cy - y) > 3:
                                pyautogui.moveTo(x, y, duration=0)
                        elif ev == "click":
                            pyautogui.click(x, y)
                        elif ev == "double_click":
                            pyautogui.doubleClick(x, y)
                        elif ev == "right_click":
                            pyautogui.rightClick(x, y)
                        elif ev == "scroll":
                            pyautogui.scroll(int(d.get("dy", 0)), x=x, y=y)
                    except Exception:
                        pass

                elif pkt_type == PKT_KEYBOARD:
                    d  = unpack_json(payload)
                    ev = d.get("event")
                    try:
                        if ev == "press":
                            key = d.get("key", "")
                            if key:
                                pyautogui.press(key)
                        elif ev == "hotkey":
                            keys = d.get("keys", [])
                            if keys:
                                pyautogui.hotkey(*keys)
                        elif ev == "write":
                            text = d.get("text", "")
                            if text:
                                pyautogui.write(text, interval=0.01)
                    except Exception:
                        pass

                elif pkt_type == PKT_CHAT:
                    d = unpack_json(payload)
                    msg = d.get("text", "")
                    self.log(f"Чат от {login}: {msg}")
                    write_log(f"CHAT: {login}: {msg}")
                    send(pack_json(PKT_CHAT, d))

                elif pkt_type == PKT_FILE_INFO:
                    self._recv_file(conn, unpack_json(payload), login)

        except (ConnectionError, OSError):
            pass
        except Exception as e:
            self.log(f"Ошибка в сессии {login}: {e}")
        finally:
            active.clear()
            try:
                self._sessions.remove(active)
            except ValueError:
                pass
            try:
                conn.close()
            except Exception:
                pass
            self.del_conn(ip)
            write_log(f"DISCONNECTED: user={login} ip={ip}")
            self.log(f"Отключён: {login} @ {ip}")

    def _recv_file(self, conn, info, login):
        from common.protocol import recv_packet, PKT_FILE_DATA
        filename = info.get("filename", "file")
        filesize = info.get("filesize", 0)
        save_dir = os.path.join(os.path.dirname(__file__), "received")
        os.makedirs(save_dir, exist_ok=True)
        path = os.path.join(save_dir, filename)
        self.log(f"Приём файла: {filename} ({filesize} байт)")
        write_log(f"FILE: {filename} {filesize}b from {login}")
        got = 0
        with open(path, "wb") as f:
            while got < filesize:
                ptype, data = recv_packet(conn)
                if ptype == PKT_FILE_DATA:
                    f.write(data)
                    got += len(data)
                else:
                    break
        self.log(f"Файл сохранён: {path}")

    def _reset_ui(self):
        self._running = False
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")
        self.lbl_status.configure(text="Остановлен", fg="#e63946")
        self.lbl_addr.configure(text="")

    def _stop(self):
        self._running = False
        # закрываем все активные сессии
        for active in list(self._sessions):
            try:
                active.clear()
            except Exception:
                pass
        self._sessions.clear()
        if self._srv_sock:
            try:
                self._srv_sock.close()
            except Exception:
                pass
        self.btn_start.configure(state="normal")
        self.btn_stop.configure(state="disabled")
        self.lbl_status.configure(text="Остановлен", fg="#e63946")
        self.lbl_addr.configure(text="")
        self.log("Сервер остановлен")
        for item in self.tbl.get_children():
            self.tbl.delete(item)

    def _on_close(self):
        self._stop()
        self.root.destroy()

    def run(self):
        self.log("Готов к работе. Нажмите Запустить.")
        self.root.mainloop()


if __name__ == "__main__":
    app = ServerGUI()
    app.run()
