# auth.py
# Хранение и проверка учётных данных.
# Пароли хранятся как SHA-256 хэши в users.json

import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from common.crypto import hash_password

USERS_FILE = os.path.join(os.path.dirname(__file__), "users.json")


def _load():
    if not os.path.exists(USERS_FILE):
        return {}
    with open(USERS_FILE, "r", encoding="utf-8") as f:
        return json.load(f)


def _save(users):
    with open(USERS_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, ensure_ascii=False, indent=2)


def add_user(login, password):
    users = _load()
    users[login] = hash_password(password)
    _save(users)
    print(f"User added: {login}")


def verify_user(login, pwd_hash):
    users = _load()
    if login not in users:
        return False
    return users[login] == pwd_hash


def ensure_default_user():
    users = _load()
    if not users:
        add_user("admin", "admin123")
        print("Default user created: admin / admin123")
        print("Please change the password in users.json")
